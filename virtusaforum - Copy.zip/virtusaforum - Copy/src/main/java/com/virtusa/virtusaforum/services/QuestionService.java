package com.virtusa.virtusaforum.services;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.virtusa.virtusaforum.models.Answer;
import com.virtusa.virtusaforum.models.Question;
import com.virtusa.virtusaforum.models.User;
import com.virtusa.virtusaforum.repository.AnswerRepository;
import com.virtusa.virtusaforum.repository.QuestionRepository;
@Service
public class QuestionService {
	@Autowired
	private QuestionRepository questionRepo;
	@Autowired
	private UserServices userService;
	@Autowired
	private AnswerService answerService;
	@Autowired
	private AnswerRepository answerRepo;
	public Question saveQuestion(String question,int userId)
	{
		Question newQuestion = new Question();
		newQuestion.setQuestion(question);
		newQuestion.setCreated(Calendar.getInstance().getTime());
		User user=userService.getUserByUserId(userId);
		newQuestion.setUser(user);
		return questionRepo.save(newQuestion);
	}
	public Question getQuestionByUserId(int userId)
	{
		
		
		return questionRepo.findById(userId).orElse(null);
	}
	public Question getQuestionById(int questionId) {
		// TODO Auto-generated method stub
		return questionRepo.findById(questionId).orElse(null);
	}
	
	
	public List<Question> getAllQuestions()
	{
		Calendar cal = Calendar.getInstance();
		Date today = cal.getTime();
		cal.add(Calendar.DATE, -2);
		Date expiryDate = cal.getTime();
		 
		
		List<Question> questions = questionRepo.deleteByCreatedOnBefore(expiryDate);
		//System.out.println(questions.get(0).getQuestion());
		System.out.println(questions.size());
		for(int i=0;i<questions.size();i++)
		{
			List<Answer> answer =answerService.getAnswerByQuestion(questions.get(i).getQuestionId());
			for(int j=0;i<answer.size();i++)
				answerRepo.deleteById(answer.get(j).getAnswerId());
			questionRepo.deleteById(questions.get(i).getQuestionId());
		}
		List<Question> question =questionRepo.findAll();
		System.out.println(question.size());
		return question;
	}
	public void uploadFile(MultipartFile file) {
		String folder = System.getProperty("user.dir")+"/src/main/resources/static/images/questions/";
		try {
			byte[] bytes=file.getBytes();
			Path path=Paths.get(folder+file.getOriginalFilename());
			Files.write(path, bytes);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace(); 
		}
	}
}