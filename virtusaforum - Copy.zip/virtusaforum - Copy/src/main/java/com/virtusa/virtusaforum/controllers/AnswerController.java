package com.virtusa.virtusaforum.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.virtusa.virtusaforum.models.Answer;
import com.virtusa.virtusaforum.models.Question;
import com.virtusa.virtusaforum.services.AnswerService;

@Controller
@SessionAttributes("question")
public class AnswerController {
	
	@Autowired
	HttpSession httpSession;
	@Autowired
	private AnswerService answerService;
	private static final Logger log=LogManager.getLogger(AnswerController.class);
	@PostMapping("/answer")
	public String answer(@Param("questionId") String questionId,Model model)
	{
		//System.out.println(question);
		System.out.println(httpSession.getAttribute("userId"));
		System.out.println(questionId);
		httpSession.setAttribute("questionId", questionId);
		model.addAttribute("answers",answerService.getAnswerByQuestion(Integer.parseInt(questionId)));
		return "answer";
	}
	@PostMapping("/saveAnswer")
	public String saveAnswer(@RequestParam String answer,Model model)
	{
		int userId=Integer.parseInt(httpSession.getAttribute("userId").toString());
		System.out.println(userId);
		int questionId=Integer.parseInt(httpSession.getAttribute("questionId").toString());
		System.out.println("Answer: "+answer);
		model.addAttribute("answer",answerService.saveAnswer(answer,questionId,userId));
		model.addAttribute("answers",answerService.getAnswerByQuestion(questionId));
		log.info("answer added sucessfully");
		return "answer";
	}
	@RequestMapping("/answer")
	public String listAnswer(Model model,@ModelAttribute int questionId)
	{
		List<Answer> listAnswer=answerService.getAllAnswers();
		model.addAttribute("listAnswer",listAnswer);
		return "answer";
	}
}
