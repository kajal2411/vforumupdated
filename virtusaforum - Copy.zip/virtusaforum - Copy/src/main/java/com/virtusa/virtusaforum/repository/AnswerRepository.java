package com.virtusa.virtusaforum.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.virtusaforum.models.Answer;

public interface AnswerRepository extends JpaRepository<Answer,Integer>{

	@Query("select ans from Answer ans where ans.question.questionId =:questionId")
	List<Answer> getAnswersByQuestion(@Param("questionId") int questionId);

	

}
