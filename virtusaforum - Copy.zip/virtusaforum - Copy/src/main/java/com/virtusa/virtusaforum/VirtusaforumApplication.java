package com.virtusa.virtusaforum;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@ComponentScan(basePackages = {"com.virtusa.virtusaforum.*"})
@EnableAutoConfiguration
@EnableJpaRepositories(basePackages = {"com.virtusa.virtusaforum.*"})
@EntityScan(basePackages = {"com.virtusa.virtusaforum.*"})
public class VirtusaforumApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusaforumApplication.class, args);
	}

}


