package com.virtusa.virtusaforum.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.virtusaforum.models.User;
import com.virtusa.virtusaforum.repository.UserRepository;

@Service("userservice")
public class UserServices  {
	@Autowired
	private UserRepository userRepo;
	
	public User saveUser(User user)
	{
		return userRepo.save(user);
	}
	public User getUserByUserId(int userId)
	{
		return userRepo.getOne(userId);
	}
	public User getUser(int userId) {
		return userRepo.getOne(userId);
	}
	//current change 
	public List<User> getAllUsers()
	{
		List<User> user =userRepo.findAll();
		System.out.println(user.size());
		return user;
	}
}