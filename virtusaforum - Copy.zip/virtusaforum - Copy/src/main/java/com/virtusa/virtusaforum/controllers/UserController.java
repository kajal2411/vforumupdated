package com.virtusa.virtusaforum.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.virtusa.virtusaforum.models.User;
import com.virtusa.virtusaforum.services.UserServices;
@Controller
@SessionAttributes("userId")
public class UserController {
	
	//change
	@Autowired
	public UserServices userService;
	
	//current changes
	@RequestMapping("/userprofile")
	public String viewHomePage(Model model)
	{
	List<User> listUsers=userService.getAllUsers();
	model.addAttribute("listUsers",listUsers);
	return "userprofile";
	}
	/*
	@RequestMapping("/userprofile")
	public String viewHomePage(Model model,int userId)
	{
		User user=userService.getUserByUserId(userId);
		model.addAttribute("listUsers",user);
		return "userprofile";
	}*/
	
}
